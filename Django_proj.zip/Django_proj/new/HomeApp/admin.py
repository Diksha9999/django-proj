from django.contrib import admin
from HomeApp.models import Contact


# Register your models here.
admin.site.register(Contact)